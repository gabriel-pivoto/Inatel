package Control;

public interface VideoConferencia {
    public void fazStreaming();
}
