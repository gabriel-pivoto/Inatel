package Control;

public interface Compartilhamento {

    public void compartilhar();

}
