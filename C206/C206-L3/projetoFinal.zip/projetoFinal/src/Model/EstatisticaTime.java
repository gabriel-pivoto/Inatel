package Model;

public interface EstatisticaTime {

    void infoTime();
}
