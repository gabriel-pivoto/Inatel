package Model;

public interface InfoTime {

    void info();
}
