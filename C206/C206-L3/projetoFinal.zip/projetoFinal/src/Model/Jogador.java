package Model;

public class Jogador {

    boolean cartao;
    int quantGols;

    public void tomarCartao(boolean cartaos){

    }

    public void quantGol (int gols){

    }
}
