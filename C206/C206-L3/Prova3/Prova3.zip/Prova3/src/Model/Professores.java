package Model;
public class Professores {
    public String nome;
    public String materia;
    public String cpf;
}