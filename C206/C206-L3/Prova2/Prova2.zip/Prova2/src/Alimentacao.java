public interface Alimentacao {

    public void comendo();
}
