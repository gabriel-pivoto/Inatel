public interface Controle {

    public void taxa();
    public void mostraInfo();



}
